import shutil
shutil.make_archive("new_2023","zip","2023")